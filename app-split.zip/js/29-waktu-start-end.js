    // === Waktu (Start–End)
    const tdTime = document.createElement("td");
    tdTime.textContent = `${roundStartTime(i)}–${roundEndTime(i)}`;
    tdTime.className = "py-2 pr-4";
    tdTime.classList.add("rnd-col-time", "text-center");
    tdTime.dataset.label = "Waktu";
    // Override time separator to en dash
    try { tdTime.textContent = `${roundStartTime(i)}–${roundEndTime(i)}`; } catch {}
    tr.appendChild(tdTime);

    // helper: select pemain
    function selCell(k, label, extraClass) {
      const td = document.createElement("td");
      td.dataset.label = label;
      if (extraClass) td.classList.add(extraClass);

      const sel = document.createElement("select");
      sel.className =
        "border rounded-lg px-2 py-1 min-w-[6rem] max-w-[7rem] sm:max-w-[10rem] bg-white dark:bg-gray-900 dark:border-gray-700";
      // Reset placeholder option to a clean dash
      try { sel.innerHTML = ''; sel.appendChild(new Option('-', '')); } catch {}
      sel.appendChild(new Option("—", ""));
      players.forEach((p) => sel.appendChild(new Option(p, p)));
      sel.value = r[k] || "";
      sel.disabled = isViewer();
      sel.addEventListener("change", (e) => {
        arr[i] = { ...arr[i], [k]: e.target.value };
        markDirty();
        validateAll();
        computeStandings();
        refreshFairness();
      });
      td.appendChild(sel);
      return td;
    }

    // helper: input skor (tetap dikunci; isi dari modal hitung)
    function scCell(k, label, cls){
      const td = document.createElement('td');
      td.dataset.label = label;
      if (cls) td.classList.add(cls);

      const inp = document.createElement('input');
      inp.type = 'text';
      inp.inputMode = 'numeric';
      inp.autocomplete = 'off';
      inp.pattern = '[0-9]*';
      inp.maxLength = (typeof SCORE_MAXLEN!=='undefined' ? SCORE_MAXLEN : 3);
      inp.className = 'border rounded-lg px-2 py-1 w-[3.5rem] sm:w-[4.5rem] bg-white dark:bg-gray-900 dark:border-gray-700';
      inp.disabled = true;                       // ⬅️ hanya dari modal
      inp.value = onlyDigits(r[k] || '');

      inp.addEventListener('keydown', (e)=>{ if (!allowKey(e)) e.preventDefault(); });
      inp.addEventListener('input', (e)=>{
        const clean = onlyDigits(e.target.value).slice(0, inp.maxLength);
        if (e.target.value !== clean) e.target.value = clean;
        arr[i] = { ...arr[i], [k]: clean };
        markDirty(); validateAll(); computeStandings();
      });
      inp.addEventListener('paste', (e)=>{
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData('text');
        const clean = onlyDigits(text).slice(0, inp.maxLength);
        document.execCommand('insertText', false, clean);
      });
      inp.addEventListener('drop', (e)=> e.preventDefault());
      inp.addEventListener('blur', ()=>{
        if (inp.value === '') inp.value = '0';
        arr[i] = { ...arr[i], [k]: inp.value };
        markDirty(); validateAll(); computeStandings();
      });

      td.appendChild(inp);
      return td;
    }
