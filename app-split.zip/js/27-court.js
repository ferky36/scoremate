// ================== COURT ================== //
function renderCourt(container, arr) {
  const start = byId("startTime").value || "19:00";
  const minutes = parseInt(byId("minutesPerRound").value || "12", 10);
  const R = parseInt(byId("roundCount").value || "10", 10);
  const [h, m] = start.split(":").map(Number);
  const base = new Date();
  base.setHours(h || 19, m || 0, 0, 0);

  container.innerHTML = "";
  const wrapper = document.createElement("div");
  wrapper.className = "court-wrapper overflow-x-auto";

  const table = document.createElement("table");
  table.className = "min-w-full text-sm dark-table";
  table.classList.add("rnd-table"); // ⬅️ aktifkan card-mode di HP
  table.innerHTML = `
    <thead>
      <tr class="border-b border-gray-200 dark:border-gray-700">
        <th class="py-2 pr-4"></th>
        <th class="py-2 pr-4">Jadwal</th>
        <th class="py-2 pr-4">Waktu</th>
        <th class="py-2 pr-4">Player1A</th>
        <th class="py-2 pr-4">Player2A</th>
        <th class="py-2 pr-4">Player1B</th>
        <th class="py-2 pr-4">Player2B</th>
        <th class="py-2 pr-4">Skor Tim A</th>
        <th class="py-2 pr-4">Skor Tim B</th>
        <th class="py-2 pr-4">Action</th>
      </tr>
    </thead>
    <tbody></tbody>`;
  const tbody = table.querySelector("tbody");

  for (let i = 0; i < R; i++) {
    const r = arr[i] || {
      a1: "", a2: "", b1: "", b2: "", scoreA: "", scoreB: ""
    };
    const t0 = new Date(base.getTime() + i * minutes * 60000);
    const t1 = new Date(t0.getTime() + minutes * 60000);

    const tr = document.createElement("tr");
    tr.className =
      "border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/40";
    tr.draggable = !isViewer();
    tr.dataset.index = i;
    tr.addEventListener("dragstart", (e) => {
      if (isViewer()) { e.preventDefault(); return; }
      tr.classList.add("row-dragging");
      e.dataTransfer.setData("text/plain", String(i));
    });
    tr.addEventListener("dragend", () => tr.classList.remove("row-dragging"));
    tr.addEventListener("dragover", (e) => {
      if (isViewer()) { e.preventDefault(); return; }
      e.preventDefault();
      tr.classList.add("row-drop-target");
    });
    tr.addEventListener("dragleave", () =>
      tr.classList.remove("row-drop-target")
    );
    tr.addEventListener("drop", (e) => {
      if (isViewer()) { e.preventDefault(); return; }
      e.preventDefault();
      tr.classList.remove("row-drop-target");
      const from = Number(e.dataTransfer.getData("text/plain"));
      const to = Number(tr.dataset.index);
      if (isNaN(from) || isNaN(to) || from === to) return;
      const item = arr.splice(from, 1)[0];
      arr.splice(to, 0, item);
      markDirty();
      renderAll();
    });
