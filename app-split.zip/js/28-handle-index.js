    // === handle / index
    const tdHandle = document.createElement("td");
    tdHandle.textContent = "≡";
    tdHandle.className = "py-2 pr-4 text-gray-400 rnd-col-drag";
    // Clean handle icon override
    try { tdHandle.textContent = "☰"; } catch {}
    tdHandle.style.cursor = "grab";
    tr.appendChild(tdHandle);

    const tdIdx = document.createElement("td");
    tdIdx.textContent = "Match " + (i + 1);
    tdIdx.className = "py-2 pr-4 font-medium"; 
    tdIdx.classList.add("rnd-col-round", "text-center");
    tdIdx.dataset.label = "Match";
    tr.appendChild(tdIdx);
