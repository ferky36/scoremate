// ================== PLAYERS UI ================== //
function escapeHtml(s) {
  return s.replace(
    /[&<>'"]/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[
        c
      ])
  );
}
function renderPlayersList() {
  const ul = byId("playersList");
  ul.innerHTML = "";
  players.forEach((name, idx) => {
    const li = document.createElement("li");
    li.className =
      "flex items-center gap-2 px-3 py-2 rounded-lg border bg-white dark:bg-gray-900 dark:border-gray-700";
    li.innerHTML =
      "<span class='player-name flex-1'>" +
      escapeHtml(name) +
      "</span><button class='del text-red-600 hover:underline text-xs'>hapus</button>";