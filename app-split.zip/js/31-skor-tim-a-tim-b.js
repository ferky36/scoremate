    // === Skor Tim A | Tim B
    const tdSA = scCell("scoreA","Skor"); tdSA.classList.add("rnd-scoreA");
    const tdSB = scCell("scoreB","Skor"); tdSB.classList.add("rnd-scoreB");

    tr.appendChild(tdSA);
    tr.appendChild(tdSB);

    // Viewer mode: tampilkan kolom indikator (Live/Selesai) saja, tanpa tombol aksi
    if (isViewer() && !isScoreOnlyMode()) {
      const tdCalcV = document.createElement('td');
      tdCalcV.dataset.label = 'Aksi';
      tdCalcV.className = 'rnd-col-actions';
      // badge Live
      const liveV = document.createElement('span');
      liveV.className = 'inline-flex items-center gap-1 mr-2 px-2 py-0.5 rounded-full text-xs bg-red-600 text-white live-badge';
      liveV.textContent = 'Live';
      if (!(r.startedAt && !r.finishedAt)) liveV.classList.add('hidden');
      tdCalcV.appendChild(liveV);
      // badge Selesai
      const doneV = document.createElement('span');
      doneV.className = 'inline-flex items-center gap-1 mr-2 px-2 py-0.5 rounded-full text-xs bg-gray-600 text-white done-badge';
      doneV.textContent = 'Selesai';
      if (!r.finishedAt) doneV.classList.add('hidden');
      tdCalcV.appendChild(doneV);

      tr.appendChild(tdCalcV);
      tbody.appendChild(tr);
      // Tambahkan baris jeda juga di mode viewer (agar waktu jeda terlihat)
      const _showBreakEl = byId('showBreakRows');
      const showBreak = true; // paksa tampil di viewer
      const brkMin = parseInt(byId('breakPerRound').value || '0', 10);
      if (showBreak && brkMin > 0 && i < R-1) {
        const trBreak = document.createElement('tr');
        trBreak.className = 'text-xs text-gray-500 dark:text-gray-400 rnd-break-row';
        const tdBreak = document.createElement('td');
        const fullCols = table.querySelector('thead tr').children.length;
        tdBreak.colSpan = fullCols;
        tdBreak.className = 'py-1 text-center opacity-80';
        try { tdBreak.textContent = `Jeda ${brkMin}:00 - Next ${roundStartTime(i+1)}`; } catch {}
        tdBreak.textContent = `Jeda ${brkMin}:00 - Next ${roundStartTime(i+1)}`;
        trBreak.appendChild(tdBreak);
        try { tdBreak.textContent = `Jeda ${brkMin}:00 - Next ${roundStartTime(i+1)}`; } catch {}
        tbody.appendChild(trBreak);
      }
      // lanjut ke ronde berikutnya tanpa tombol aksi
      continue;
    }

