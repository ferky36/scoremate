  // ================ SUMMARY ================ //
  const totalDates = new Set(sessionsArr.map(s=>s.date)).size;
  const totalGames = sessionsArr.reduce((sum,s)=>{
    const r1 = (court==='both'||court==='1') ? (s.rounds1||[]).filter(r=>r.a1&&r.a2&&r.b1&&r.b2).length : 0;
    const r2 = (court==='both'||court==='2') ? (s.rounds2||[]).filter(r=>r.a1&&r.a2&&r.b1&&r.b2).length : 0;
    return sum + r1 + r2;
  },0);
  const uniquePlayers = new Set(arr.map(x=>x.player)).size;
  byId('reportSummary').textContent =
    `Rentang: ${from} → ${to} • Tanggal: ${totalDates} • Game: ${totalGames} • Pemain: ${uniquePlayers}`;

  // Normalize report summary text (clean separators)
  try {
    byId('reportSummary').textContent = `Rentang: ${from} - ${to} | Tanggal: ${totalDates} | Game: ${totalGames} | Pemain: ${uniquePlayers}`;
  } catch {}

  // table
  const tbody = byId('reportTable').querySelector('tbody');
  tbody.innerHTML='';
  arr.forEach(s=>{
    const tr=document.createElement('tr');
    tr.className = s.rank===1?'rank-1': s.rank===2?'rank-2': s.rank===3?'rank-3':'';
    tr.innerHTML = `
      <td class="py-2 pr-4 font-semibold">${s.rank}</td>
      <td class="py-2 pr-4 font-medium">${escapeHtml(s.player)}</td>
      <td class="py-2 pr-4">${s.games}</td>
      <td class="py-2 pr-4">${s.total}</td>
      <td class="py-2 pr-4">${s.diff}</td>
      <td class="py-2 pr-4">${s.win}</td>
      <td class="py-2 pr-4">${s.lose}</td>
      <td class="py-2 pr-4">${s.draw}</td>
      <td class="py-2 pr-4">${(s.winRate*100).toFixed(1)}%</td>`;
    tbody.appendChild(tr);
  });
