// ===== Local storage helpers =====
const STORAGE_KEY = 'mixam_sessions_v1';

function readAllSessionsLS() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
  catch { return {}; }
}
function writeAllSessionsLS(obj) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
}
