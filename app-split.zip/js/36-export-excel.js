  // ======================= export Excel ======================= //
  byId('btnExportReportExcel').onclick = ()=>{
    // Data yang sudah dihitung sebelumnya
    // arr: hasil aggregateStats(...) berisi {player,games,total,diff,win,lose,draw,winRate,rank}
    const from = byId('repFrom').value || '0000-01-01';
    const to   = byId('repTo').value   || '9999-12-31';
    const court= byId('repCourt').value; // 'both' | '1' | '2'
    const title = `Report ${from} to ${to} (Lap: ${court})`;

    // Header + rows
    const wsData = [
      [title],
      [],
      ['Rank','Pemain','Main','Total','Selisih','Menang','Kalah','Seri','WinRate']
    ];

    arr.forEach(s=>{
      wsData.push([
        s.rank,
        s.player,
        s.games,
        s.total,
        s.diff,
        s.win,
        s.lose,
        s.draw,
        (s.winRate*100).toFixed(1) + '%'
      ]);
    });

    // Buat workbook & sheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(wsData);

    // Auto width kolom sederhana
    const colWidths = [
      { wch: 6 },  // Rank
      { wch: 18 }, // Pemain
      { wch: 6 },  // Main
      { wch: 8 },  // Total
      { wch: 8 },  // Selisih
      { wch: 7 },  // W
      { wch: 7 },  // L
      { wch: 7 },  // D
      { wch: 9 }   // WinRate
    ];
    ws['!cols'] = colWidths;

    // Bold untuk header
    const headerRow = 3; // baris ke-3 (1-based) berisi header
    const headerRange = XLSX.utils.encode_range({ s:{r:headerRow-1,c:0}, e:{r:headerRow-1,c:8} });
    const headerCells = XLSX.utils.decode_range(headerRange);
    for(let C = headerCells.s.c; C <= headerCells.e.c; C++){
      const cellAddr = XLSX.utils.encode_cell({r:headerRow-1, c:C});
      if(ws[cellAddr]) ws[cellAddr].s = { font: { bold: true } };
    }

    XLSX.utils.book_append_sheet(wb, ws, 'Klasemen');
    const fname = `report_${from}_to_${to}.xlsx`;
    XLSX.writeFile(wb, fname);
  };

}

