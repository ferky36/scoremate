    // === Baris jeda (opsional)
    // Viewer: paksa tampil (abaikan toggle) agar jeda tetap terlihat sesuai setelan menit/jeda
    const _showBreakEl = byId('showBreakRows');
    const showBreak = isViewer() ? true : (_showBreakEl?.checked);
    const brkMin = parseInt(byId('breakPerRound').value || '0', 10);
    if (showBreak && brkMin > 0 && i < R-1) {
      const trBreak = document.createElement('tr');
      trBreak.className = 'text-xs text-gray-500 dark:text-gray-400 rnd-break-row';
      const tdBreak = document.createElement('td');
      const fullCols = table.querySelector('thead tr').children.length;
      tdBreak.colSpan = fullCols;
      tdBreak.className = 'py-1 text-center opacity-80';
      // Clean break text override
      try { tdBreak.textContent = `Jeda ${brkMin}:00 • Next ${roundStartTime(i+1)}`; } catch {}
      tdBreak.textContent = `🕒 Jeda ${brkMin}:00 • Next ${roundStartTime(i+1)}`;
      trBreak.appendChild(tdBreak);
      // Force clean break text (override any garbled replacements)
      try { tdBreak.textContent = `Jeda ${brkMin}:00 • Next ${roundStartTime(i+1)}`; } catch {}
      tbody.appendChild(trBreak);
    }
  }

  wrapper.appendChild(table);
  container.appendChild(wrapper);
}


function renderCourtActive(){
  ensureRoundsLengthForAllCourts();
  const container = byId('courtContainer');
  container.innerHTML = '';
  const arr = roundsByCourt[activeCourt] || [];
  renderCourt(container, arr);  // gunakan fungsi renderCourt Anda yang sudah ada
}

