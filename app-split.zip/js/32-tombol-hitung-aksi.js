    // === tombol Hitung (aksi)
    const tdCalc = document.createElement('td');
    tdCalc.dataset.label = 'Aksi';
    tdCalc.className = 'rnd-col-actions';
    // Live & Done badges
    const live = document.createElement('span');
    live.className = 'inline-flex items-center gap-1 mr-2 px-2 py-0.5 rounded-full text-xs bg-red-600 text-white live-badge';
    live.textContent = 'Live';
    if (!(r.startedAt && !r.finishedAt)) live.classList.add('hidden');
    tdCalc.appendChild(live);
    const done = document.createElement('span');
    done.className = 'inline-flex items-center gap-1 mr-2 px-2 py-0.5 rounded-full text-xs bg-gray-600 text-white done-badge';
    done.textContent = 'Selesai';
    if (!r.finishedAt) done.classList.add('hidden');
    tdCalc.appendChild(done);
    const btnCalc = document.createElement('button');
    btnCalc.className = 'px-3 py-1.5 rounded-lg border dark:border-gray-700 text-sm w-full sm:w-auto';
    btnCalc.textContent = (r.scoreA || r.scoreB) ? '🔁 Hitung Ulang' : '🧮 Mulai Main';
    btnCalc.addEventListener('click', ()=> openScoreModal(activeCourt, i));
    // Clean label override
    try { btnCalc.textContent = (r.scoreA || r.scoreB) ? 'Hitung Ulang' : 'Mulai Main'; } catch {}
    tdCalc.appendChild(btnCalc);
    tr.appendChild(tdCalc);
    // Override visibility/label for table action button based on role and view mode
    try {
      const hasScore = (r.scoreA !== undefined && r.scoreA !== null && r.scoreA !== '') || (r.scoreB !== undefined && r.scoreB !== null && r.scoreB !== '');
      const allowStart = (typeof canEditScore === 'function') ? canEditScore() : !isViewer();
      const allowRecalc = (typeof isOwnerNow==="function") ? isOwnerNow() : !!window._isOwnerUser; // only owner can recalc
      if (hasScore) {
        btnCalc.textContent = 'Hitung Ulang';
        if (!allowRecalc) btnCalc.classList.add('hidden');
      } else {
        btnCalc.textContent = 'Mulai Main';
        const started = !!r.startedAt;
        if (!allowStart || started) btnCalc.classList.add('hidden');
      }
    } catch {}

    tbody.appendChild(tr);
