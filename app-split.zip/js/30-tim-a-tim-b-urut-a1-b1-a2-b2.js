    // === Tim A | Tim B (urut: A1 | B1, A2 | B2)
    const tdA1 = selCell("a1", "TIM A", "rnd-teamA-1");
    const tdA2 = selCell("a2", " ", "rnd-teamA-2");
    const tdB1 = selCell("b1", "TIM B", "rnd-teamB-1");
    const tdB2 = selCell("b2", " ", "rnd-teamB-2");

    tr.appendChild(tdA1);
    tr.appendChild(tdA2);
    tr.appendChild(tdB1);
    tr.appendChild(tdB2);
