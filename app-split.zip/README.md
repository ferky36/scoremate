# Split of app.js

This folder contains a lossless split of your original `app.js` into 40 parts.
- **No variable/function names or logic are changed.** The code is copied verbatim, only split into files.
- Load them **in this exact order** to preserve globals and dependencies.

## How to include in HTML

```html
<script src="./js/01-prolog.js"></script>
<script src="./js/02-helpers.js"></script>
<script src="./js/03-join-open-time-tanggal-jam-terpisah.js"></script>
<script src="./js/04-local-storage-helpers.js"></script>
<script src="./js/05-supabase-cloud-mode-helpers.js"></script>
<script src="./js/06-util-state-ui-for-event-create-search-button.js"></script>
<script src="./js/07-event-location-simple.js"></script>
<script src="./js/08-title-rename-editor-only.js"></script>
<script src="./js/09-auth-redirect-helper-github-pages-base.js"></script>
<script src="./js/10-auth-helpers.js"></script>
<script src="./js/11-join-event-viewer-self-join.js"></script>
<script src="./js/12-toast-helper.js"></script>
<script src="./js/13-minor-delta-applier-hindari-full-render-jika-hanya-1-match-y.js"></script>
<script src="./js/14-save-silent-untuk-autosave-aksi-internal.js"></script>
<script src="./js/15-state.js"></script>
<script src="./js/16-paid-flag-playermeta-realtime.js"></script>
<script src="./js/17-access-control.js"></script>
<script src="./js/18-theme.js"></script>
<script src="./js/19-sessions.js"></script>
<script src="./js/20-players-ui.js"></script>
<script src="./js/21-meta-mini-controls-gender-level.js"></script>
<script src="./js/22-editor-players-panel-relocation.js"></script>
<script src="./js/23-max-players-editor.js"></script>
<script src="./js/24-event-location-editor.js"></script>
<script src="./js/25-americano-32-point-rotasi-servis-badge-di-score-modal.js"></script>
<script src="./js/26-rename-helpers-robust-mapping-for-multi-rename.js"></script>
<script src="./js/27-court.js"></script>
<script src="./js/28-handle-index.js"></script>
<script src="./js/29-waktu-start-end.js"></script>
<script src="./js/30-tim-a-tim-b-urut-a1-b1-a2-b2.js"></script>
<script src="./js/31-skor-tim-a-tim-b.js"></script>
<script src="./js/32-tombol-hitung-aksi.js"></script>
<script src="./js/33-baris-jeda-opsional.js"></script>
<script src="./js/34-render-validation-standings.js"></script>
<script src="./js/35-summary.js"></script>
<script src="./js/36-export-excel.js"></script>
<script src="./js/37-auto-fill-tab-aktif.js"></script>
<script src="./js/38-score-modal.js"></script>
<script src="./js/39-expand-collapse-filter-jadwal.js"></script>
<script src="./js/40-auth-ui-bindings.js"></script>
```

> Tip: Put the `<script>` tags **at the end of `<body>`** to ensure the DOM is ready.

## Files (ordered)
01. `js/01-prolog.js`  (lines 1–1)
02. `js/02-helpers.js`  (lines 2–75)
03. `js/03-join-open-time-tanggal-jam-terpisah.js`  (lines 76–164)
04. `js/04-local-storage-helpers.js`  (lines 165–175)
05. `js/05-supabase-cloud-mode-helpers.js`  (lines 176–235)
06. `js/06-util-state-ui-for-event-create-search-button.js`  (lines 236–243)
07. `js/07-event-location-simple.js`  (lines 244–402)
08. `js/08-title-rename-editor-only.js`  (lines 403–475)
09. `js/09-auth-redirect-helper-github-pages-base.js`  (lines 476–482)
10. `js/10-auth-helpers.js`  (lines 483–538)
11. `js/11-join-event-viewer-self-join.js`  (lines 539–787)
12. `js/12-toast-helper.js`  (lines 788–1069)
13. `js/13-minor-delta-applier-hindari-full-render-jika-hanya-1-match-y.js`  (lines 1070–1193)
14. `js/14-save-silent-untuk-autosave-aksi-internal.js`  (lines 1194–1263)
15. `js/15-state.js`  (lines 1264–1283)
16. `js/16-paid-flag-playermeta-realtime.js`  (lines 1284–1340)
17. `js/17-access-control.js`  (lines 1341–1472)
18. `js/18-theme.js`  (lines 1473–1498)
19. `js/19-sessions.js`  (lines 1499–1979)
20. `js/20-players-ui.js`  (lines 1980–2000)
21. `js/21-meta-mini-controls-gender-level.js`  (lines 2001–2174)
22. `js/22-editor-players-panel-relocation.js`  (lines 2175–2289)
23. `js/23-max-players-editor.js`  (lines 2290–2326)
24. `js/24-event-location-editor.js`  (lines 2327–2561)
25. `js/25-americano-32-point-rotasi-servis-badge-di-score-modal.js`  (lines 2562–2626)
26. `js/26-rename-helpers-robust-mapping-for-multi-rename.js`  (lines 2627–2906)
27. `js/27-court.js`  (lines 2907–2979)
28. `js/28-handle-index.js`  (lines 2980–2995)
29. `js/29-waktu-start-end.js`  (lines 2996–3071)
30. `js/30-tim-a-tim-b-urut-a1-b1-a2-b2.js`  (lines 3072–3082)
31. `js/31-skor-tim-a-tim-b.js`  (lines 3083–3131)
32. `js/32-tombol-hitung-aksi.js`  (lines 3132–3171)
33. `js/33-baris-jeda-opsional.js`  (lines 3172–3207)
34. `js/34-render-validation-standings.js`  (lines 3208–3542)
35. `js/35-summary.js`  (lines 3543–3577)
36. `js/36-export-excel.js`  (lines 3578–3642)
37. `js/37-auto-fill-tab-aktif.js`  (lines 3643–3856)
38. `js/38-score-modal.js`  (lines 3857–4602)
39. `js/39-expand-collapse-filter-jadwal.js`  (lines 4603–5261)
40. `js/40-auth-ui-bindings.js`  (lines 5262–5287)
